<?php

use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\IncomeController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\HistoryController;
use App\Http\Controllers\CustomTypeController;
use App\Http\Controllers\BankController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth'])->group(function () {
    Route::get('/', function () {
        return view('dashboard');
    })->name('dashboard');

    Route::resource('incomes', IncomeController::class);
    Route::resource('expenses', ExpenseController::class);
    Route::resource('history', HistoryController::class)->except(['edit', 'update', 'destroy']);
    Route::post('history/archive-current', [HistoryController::class, 'archiveCurrentMonth'])->name('history.archive-current');
    Route::post('custom-types', [CustomTypeController::class, 'store'])->name('custom-types.store');

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::prefix('bank')->name('bank.')->group(function () {
        Route::get('/', [BankController::class, 'index'])->name('index');
        Route::get('/connect', [BankController::class, 'connect'])->name('connect');
        Route::post('/connect', [BankController::class, 'initiate'])->name('initiate');
        Route::get('/callback', [BankController::class, 'callback'])->name('callback');
        Route::get('/{account}', [BankController::class, 'show'])->name('show');
        Route::post('/{account}/refresh', [BankController::class, 'refresh'])->name('refresh');
    });
});

require __DIR__.'/auth.php';
