<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BankAccount extends Model
{
    protected $fillable = [
        'user_id',
        'account_id',
        'account_name',
        'account_type',
        'balance',
        'currency',
        'access_token',
        'token_expires_at',
        'refresh_token'
    ];

    protected $casts = [
        'balance' => 'decimal:2',
        'token_expires_at' => 'datetime'
    ];

    protected $hidden = [
        'access_token',
        'refresh_token'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function isTokenExpired()
    {
        return $this->token_expires_at->isPast();
    }
}
