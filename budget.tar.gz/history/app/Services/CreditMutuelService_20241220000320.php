<?php

namespace App\Services;

use App\Models\BankAccount;
use Illuminate\Support\Facades\Http;
use Carbon\Carbon;

class CreditMutuelService
{
    private $baseUrl;
    private $clientId;
    private $clientSecret;
    private $redirectUri;

    public function __construct()
    {
        $this->baseUrl = config('services.creditmutuel.url');
        $this->clientId = config('services.creditmutuel.client_id');
        $this->clientSecret = config('services.creditmutuel.client_secret');
        $this->redirectUri = config('services.creditmutuel.redirect_uri');
    }

    public function getAuthorizationUrl()
    {
        $params = [
            'client_id' => $this->clientId,
            'response_type' => 'code',
            'redirect_uri' => $this->redirectUri,
            'scope' => 'aisp',
            'state' => csrf_token()
        ];

        return $this->baseUrl . '/oauth2/authorize?' . http_build_query($params);
    }

    public function getAccessToken($code)
    {
        $response = Http::withBasicAuth($this->clientId, $this->clientSecret)
            ->asForm()
            ->post($this->baseUrl . '/oauth2/token', [
                'grant_type' => 'authorization_code',
                'code' => $code,
                'redirect_uri' => $this->redirectUri
            ]);

        if ($response->successful()) {
            return $response->json();
        }

        throw new \Exception('Erreur lors de la récupération du token: ' . $response->body());
    }

    public function refreshToken(BankAccount $account)
    {
        $response = Http::withBasicAuth($this->clientId, $this->clientSecret)
            ->asForm()
            ->post($this->baseUrl . '/oauth2/token', [
                'grant_type' => 'refresh_token',
                'refresh_token' => $account->refresh_token
            ]);

        if ($response->successful()) {
            $data = $response->json();
            $account->update([
                'access_token' => $data['access_token'],
                'token_expires_at' => Carbon::now()->addSeconds($data['expires_in']),
                'refresh_token' => $data['refresh_token']
            ]);
            return true;
        }

        return false;
    }

    public function getAccounts(BankAccount $account)
    {
        if ($account->isTokenExpired()) {
            $this->refreshToken($account);
        }

        $response = Http::withToken($account->access_token)
            ->get($this->baseUrl . '/api/v1/accounts');

        if ($response->successful()) {
            return $response->json();
        }

        throw new \Exception('Erreur lors de la récupération des comptes: ' . $response->body());
    }

    public function getTransactions(BankAccount $account, $startDate = null, $endDate = null)
    {
        if ($account->isTokenExpired()) {
            $this->refreshToken($account);
        }

        $params = [];
        if ($startDate) $params['dateFrom'] = $startDate->format('Y-m-d');
        if ($endDate) $params['dateTo'] = $endDate->format('Y-m-d');

        $response = Http::withToken($account->access_token)
            ->get($this->baseUrl . "/api/v1/accounts/{$account->account_id}/transactions", $params);

        if ($response->successful()) {
            return $response->json();
        }

        throw new \Exception('Erreur lors de la récupération des transactions: ' . $response->body());
    }
}
