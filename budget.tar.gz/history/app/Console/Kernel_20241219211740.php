protected function schedule(Schedule $schedule): void
{
    // Archiver le mois précédent le premier jour de chaque mois à minuit
    $schedule->command('history:archive-last-month')
        ->monthlyOn(1, '00:00');
}
