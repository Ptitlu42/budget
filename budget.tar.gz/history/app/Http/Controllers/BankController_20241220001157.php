<?php

namespace App\Http\Controllers;

use App\Models\BankAccount;
use App\Services\NordigenService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller

class BankController extends Controller
{
    private $nordigenService;

    public function __construct(NordigenService $nordigenService)
    {
        $this->middleware('auth');
        $this->nordigenService = $nordigenService;
    }

    public function index()
    {
        $accounts = BankAccount::where('user_id', Auth::id())->get();
        return view('bank.index', compact('accounts'));
    }

    public function connect()
    {
        $banks = $this->nordigenService->getBanks('FR');
        return view('bank.connect', compact('banks'));
    }

    public function initiate(Request $request)
    {
        $validated = $request->validate([
            'bank_id' => 'required|string'
        ]);

        $requisition = $this->nordigenService->createRequisition(
            $validated['bank_id'],
            route('bank.callback')
        );

        session(['requisition_id' => $requisition['id']]);
        return redirect($requisition['link']);
    }

    public function callback(Request $request)
    {
        $requisitionId = session('requisition_id');
        $accounts = $this->nordigenService->getAccounts($requisitionId);

        foreach ($accounts['accounts'] as $accountId) {
            $details = $this->nordigenService->getAccountDetails($accountId);
            $balances = $this->nordigenService->getAccountBalances($accountId);

            BankAccount::create([
                'user_id' => Auth::id(),
                'account_id' => $accountId,
                'account_name' => $details['account']['name'] ?? 'Compte ' . substr($accountId, -4),
                'account_type' => $details['account']['product'] ?? 'unknown',
                'balance' => $balances['balances'][0]['balanceAmount']['amount'] ?? 0,
                'currency' => $balances['balances'][0]['balanceAmount']['currency'] ?? 'EUR'
            ]);
        }

        return redirect()->route('bank.index')->with('success', 'Compte bancaire connecté avec succès');
    }

    public function show(BankAccount $account)
    {
        $balances = $this->nordigenService->getAccountBalances($account->account_id);
        $transactions = $this->nordigenService->getAccountTransactions(
            $account->account_id,
            now()->subMonths(3),
            now()
        );

        return view('bank.show', compact('account', 'balances', 'transactions'));
    }

    public function refresh(BankAccount $account)
    {
        $balances = $this->nordigenService->getAccountBalances($account->account_id);
        $account->update([
            'balance' => $balances['balances'][0]['balanceAmount']['amount'] ?? $account->balance
        ]);

        return redirect()->back()->with('success', 'Solde mis à jour avec succès');
    }
}
