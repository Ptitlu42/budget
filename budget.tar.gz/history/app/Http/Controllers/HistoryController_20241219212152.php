<?php

namespace App\Http\Controllers;

use App\Models\History;
use App\Models\Income;
use App\Models\Expense;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class HistoryController extends Controller
{
    public function index()
    {
        // Vérifier si le mois précédent doit être archivé
        $lastMonth = Carbon::now()->subMonth()->startOfMonth();
        if (!History::where('month_year', $lastMonth)->exists()) {
            $this->archiveMonth($lastMonth);
        }

        $history = History::orderBy('month_year', 'desc')->get();
        return view('history.index', compact('history'));
    }

    public function create()
    {
        // Récupérer tous les mois déjà archivés
        $archivedMonths = History::pluck('month_year')->map(function($date) {
            return Carbon::parse($date)->format('Y-m');
        })->toArray();

        // Récupérer tous les mois avec des données
        $monthsWithData = collect();

        // Vérifier les revenus
        $incomeMonths = Income::select(DB::raw('DATE_FORMAT(date, "%Y-%m") as month'))
            ->groupBy('month')
            ->pluck('month');

        // Vérifier les dépenses
        $expenseMonths = Expense::select(DB::raw('DATE_FORMAT(date, "%Y-%m") as month'))
            ->groupBy('month')
            ->pluck('month');

        // Fusionner les mois uniques qui ont des données
        $monthsWithData = $incomeMonths->merge($expenseMonths)->unique()
            ->filter(function($month) use ($archivedMonths) {
                return !in_array($month, $archivedMonths);
            });

        if ($monthsWithData->isEmpty()) {
            return redirect()->route('history.index')
                ->with('error', 'Aucun mois disponible pour l\'archivage. Veuillez d\'abord ajouter des revenus et des dépenses.');
        }

        return view('history.create', ['availableMonths' => $monthsWithData]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'month_year' => 'required|date|unique:history,month_year',
            'incomes_data' => 'required|array',
            'incomes_data.*.description' => 'required|string',
            'incomes_data.*.amount' => 'required|numeric|min:0',
            'incomes_data.*.type' => 'required|in:salary,aid,other',
            'incomes_data.*.date' => 'required|date',
            'incomes_data.*.user_id' => 'required|exists:users,id',
            'expenses_data' => 'required|array',
            'expenses_data.*.description' => 'required|string',
            'expenses_data.*.amount' => 'required|numeric|min:0',
            'expenses_data.*.type' => 'required|in:rent,insurance,utilities,groceries,other',
            'expenses_data.*.date' => 'required|date',
            'expenses_data.*.is_shared' => 'boolean'
        ]);

        // Convertir la date en début de mois
        $startDate = Carbon::parse($validated['month_year'])->startOfMonth();

        // Calculer les totaux
        $total_incomes = collect($validated['incomes_data'])->sum('amount');
        $total_expenses = collect($validated['expenses_data'])->sum('amount');
        $total_shared_expenses = collect($validated['expenses_data'])
            ->where('is_shared', true)
            ->sum('amount');

        // Calculer les parts
        $shares = collect($validated['incomes_data'])
            ->groupBy('user_id')
            ->map(function ($userIncomes) use ($total_incomes) {
                $user = DB::table('users')->where('id', $userIncomes->first()['user_id'])->first();
                return [
                    'name' => $user->name,
                    'email' => $user->email,
                    'total_income' => $userIncomes->sum('amount'),
                    'share_percentage' => ($total_incomes > 0) ? ($userIncomes->sum('amount') / $total_incomes) * 100 : 0
                ];
            })->values();

        // Créer l'historique
        History::create([
            'month_year' => $startDate,
            'incomes_data' => $validated['incomes_data'],
            'expenses_data' => $validated['expenses_data'],
            'total_incomes' => $total_incomes,
            'total_expenses' => $total_expenses,
            'total_shared_expenses' => $total_shared_expenses,
            'shares_data' => $shares->toArray()
        ]);

        return redirect()->route('history.index')->with('success', 'Historique ajouté avec succès');
    }

    public function archiveMonth($date)
    {
        // Vérifier si l'historique existe déjà
        if (History::where('month_year', $date)->exists()) {
            return;
        }

        // Récupérer les revenus
        $incomes = Income::whereMonth('date', $date->month)
            ->whereYear('date', $date->year)
            ->get();

        // Récupérer les dépenses
        $expenses = Expense::whereMonth('date', $date->month)
            ->whereYear('date', $date->year)
            ->get();

        // Calculer les totaux
        $total_incomes = $incomes->sum('amount');
        $total_expenses = $expenses->sum('amount');
        $total_shared_expenses = $expenses->where('is_shared', true)->sum('amount');

        // Calculer les parts
        $shares = DB::table('incomes')
            ->join('users', 'incomes.user_id', '=', 'users.id')
            ->whereMonth('date', $date->month)
            ->whereYear('date', $date->year)
            ->select('users.name', 'users.email', DB::raw('SUM(amount) as total_income'))
            ->groupBy('users.id', 'users.name', 'users.email')
            ->get()
            ->map(function ($user) use ($total_incomes) {
                $user->share_percentage = ($total_incomes > 0) ? ($user->total_income / $total_incomes) * 100 : 0;
                return $user;
            });

        // Créer l'historique
        History::create([
            'month_year' => $date,
            'incomes_data' => $incomes->toArray(),
            'expenses_data' => $expenses->toArray(),
            'total_incomes' => $total_incomes,
            'total_expenses' => $total_expenses,
            'total_shared_expenses' => $total_shared_expenses,
            'shares_data' => $shares->toArray()
        ]);

        // Supprimer les données non verrouillées
        Income::whereMonth('date', $date->month)
            ->whereYear('date', $date->year)
            ->where('locked', false)
            ->delete();

        Expense::whereMonth('date', $date->month)
            ->whereYear('date', $date->year)
            ->where('locked', false)
            ->delete();
    }

    public function archiveCurrentMonth()
    {
        // Récupérer les données du mois en cours
        $currentMonth = Carbon::now()->startOfMonth();

        // Vérifier si l'historique existe déjà
        if (History::where('month_year', $currentMonth)->exists()) {
            return redirect()->back()->with('error', 'L\'historique pour ce mois existe déjà');
        }

        $this->archiveMonth($currentMonth);

        return redirect()->route('dashboard')->with('success', 'Le mois a été archivé avec succès');
    }

    public function show(History $history)
    {
        return view('history.show', compact('history'));
    }
}
