<?php

namespace App\Http\Controllers;

use App\Models\History;
use App\Models\Income;
use App\Models\Expense;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class HistoryController extends Controller
{
    public function index()
    {
        $history = History::orderBy('month_year', 'desc')->get();
        return view('history.index', compact('history'));
    }

    public function create()
    {
        return view('history.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'month_year' => 'required|date|unique:history,month_year',
        ]);

        // Convertir la date en début de mois
        $startDate = Carbon::parse($validated['month_year'])->startOfMonth();
        $endDate = Carbon::parse($validated['month_year'])->endOfMonth();

        // Récupérer tous les revenus du mois
        $incomes = Income::whereBetween('date', [$startDate, $endDate])->get();
        $total_incomes = $incomes->sum('amount');

        // Récupérer toutes les dépenses du mois
        $expenses = Expense::whereBetween('date', [$startDate, $endDate])->get();
        $total_expenses = $expenses->sum('amount');
        $total_shared_expenses = $expenses->where('is_shared', true)->sum('amount');

        // Calculer les parts
        $shares = DB::table('incomes')
            ->join('users', 'incomes.user_id', '=', 'users.id')
            ->whereBetween('date', [$startDate, $endDate])
            ->select('users.name', 'users.email', DB::raw('SUM(amount) as total_income'))
            ->groupBy('users.id', 'users.name', 'users.email')
            ->get()
            ->map(function ($user) use ($total_incomes) {
                $user->share_percentage = ($total_incomes > 0) ? ($user->total_income / $total_incomes) * 100 : 0;
                return $user;
            });

        // Créer l'historique
        History::create([
            'month_year' => $startDate,
            'incomes_data' => $incomes->toArray(),
            'expenses_data' => $expenses->toArray(),
            'total_incomes' => $total_incomes,
            'total_expenses' => $total_expenses,
            'total_shared_expenses' => $total_shared_expenses,
            'shares_data' => $shares->toArray()
        ]);

        return redirect()->route('history.index')->with('success', 'Historique ajouté avec succès');
    }

    public function archiveCurrentMonth()
    {
        // Récupérer les données du mois en cours
        $currentMonth = Carbon::now()->startOfMonth();

        // Vérifier si l'historique existe déjà
        if (History::where('month_year', $currentMonth)->exists()) {
            return redirect()->back()->with('error', 'L\'historique pour ce mois existe déjà');
        }

        // Récupérer les revenus
        $incomes = Income::whereMonth('date', $currentMonth->month)
            ->whereYear('date', $currentMonth->year)
            ->get();

        // Récupérer les dépenses
        $expenses = Expense::whereMonth('date', $currentMonth->month)
            ->whereYear('date', $currentMonth->year)
            ->get();

        // Calculer les parts
        $totalIncomes = Income::sum('amount');
        $shares = DB::table('incomes')
            ->join('users', 'incomes.user_id', '=', 'users.id')
            ->select('users.name', 'users.email', DB::raw('SUM(amount) as total_income'))
            ->groupBy('users.id', 'users.name', 'users.email')
            ->get()
            ->map(function ($user) use ($totalIncomes) {
                $user->share_percentage = ($totalIncomes > 0) ? ($user->total_income / $totalIncomes) * 100 : 0;
                return $user;
            });

        // Créer l'historique
        History::create([
            'month_year' => $currentMonth,
            'incomes_data' => $incomes->toArray(),
            'expenses_data' => $expenses->toArray(),
            'total_incomes' => $incomes->sum('amount'),
            'total_expenses' => $expenses->sum('amount'),
            'total_shared_expenses' => $expenses->where('is_shared', true)->sum('amount'),
            'shares_data' => $shares->toArray()
        ]);

        // Supprimer les données non verrouillées
        Income::whereMonth('date', $currentMonth->month)
            ->whereYear('date', $currentMonth->year)
            ->where('locked', false)
            ->delete();

        Expense::whereMonth('date', $currentMonth->month)
            ->whereYear('date', $currentMonth->year)
            ->where('locked', false)
            ->delete();

        return redirect()->route('dashboard')->with('success', 'Le mois a été archivé avec succès');
    }

    public function show(History $history)
    {
        return view('history.show', compact('history'));
    }
}
