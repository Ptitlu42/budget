#!/bin/bash

# Variables
REMOTE_USER="assistant"
REMOTE_HOST="51.77.137.241"
REMOTE_DIR="/home/assistant/budget-deploy"
APP_ENV="production"

# Synchroniser les fichiers
rsync -avz --exclude='.git' \
    --exclude='node_modules' \
    --exclude='vendor' \
    --exclude='.env' \
    ./ ${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_DIR}/

# Configuration sur le serveur distant
ssh ${REMOTE_USER}@${REMOTE_HOST} "cd ${REMOTE_DIR} && \
    composer install --no-dev --optimize-autoloader && \
    cp .env.example .env && \
    php artisan key:generate && \
    php artisan config:cache && \
    php artisan route:cache && \
    php artisan view:cache && \
    chmod -R 775 storage bootstrap/cache"
