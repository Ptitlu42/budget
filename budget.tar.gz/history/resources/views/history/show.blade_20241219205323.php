@extends('layouts.app')

@section('content')
    <div class="grid grid-cols-1 gap-6">
        <!-- En-tête -->
        <div class="gradient-border">
            <div class="bg-dark p-6">
                <div class="flex justify-between items-center mb-6">
                    <h1 class="text-2xl font-bold flex items-center">
                        <i class="fas fa-calendar-alt mr-2 text-white"></i>
                        <span class="text-white">{{ $history->month_year->format('F Y') }}</span>
                    </h1>
                    <a href="{{ route('history.index') }}"
                        class="text-white hover:text-gray-300 transition">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Retour à l'historique
                    </a>
                </div>

                <!-- Résumé -->
                <div class="grid grid-cols-3 gap-6 mb-6">
                    <div class="glass-effect p-4 rounded">
                        <p class="text-gray-400 mb-1">Revenus totaux</p>
                        <p class="text-2xl font-bold text-white">{{ number_format($history->total_incomes, 2, ',', ' ') }} €</p>
                    </div>
                    <div class="glass-effect p-4 rounded">
                        <p class="text-gray-400 mb-1">Dépenses totales</p>
                        <p class="text-2xl font-bold text-white">{{ number_format($history->total_expenses, 2, ',', ' ') }} €</p>
                    </div>
                    <div class="glass-effect p-4 rounded">
                        <p class="text-gray-400 mb-1">Dépenses communes</p>
                        <p class="text-2xl font-bold text-white">{{ number_format($history->total_shared_expenses, 2, ',', ' ') }} €</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Répartition -->
        <div class="grid grid-cols-2 gap-6">
            <!-- Revenus -->
            <div class="gradient-border">
                <div class="bg-dark p-6">
                    <h2 class="text-xl font-bold mb-4 flex items-center">
                        <i class="fas fa-euro-sign mr-2"></i>
                        Revenus du mois
                    </h2>
                    <div class="space-y-4">
                        @foreach(collect($history->incomes_data)->sortByDesc('date') as $income)
                            <div class="glass-effect p-4 rounded">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <p class="font-bold">{{ $income['description'] }}</p>
                                        <p class="text-sm text-gray-400">{{ \Carbon\Carbon::parse($income['date'])->format('d/m/Y') }}</p>
                                    </div>
                                    <p class="font-bold {{ $income['user_id'] === Auth::id() ? 'text-dev' : 'text-lemon' }}">
                                        {{ number_format($income['amount'], 2, ',', ' ') }} €
                                    </p>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <!-- Dépenses -->
            <div class="gradient-border">
                <div class="bg-dark p-6">
                    <h2 class="text-xl font-bold mb-4 flex items-center">
                        <i class="fas fa-shopping-cart mr-2"></i>
                        Dépenses du mois
                    </h2>
                    <div class="space-y-4">
                        @foreach(collect($history->expenses_data)->sortByDesc('date') as $expense)
                            <div class="glass-effect p-4 rounded">
                                <div class="flex justify-between items-center">
                                    <div>
                                        <p class="font-bold">{{ $expense['description'] }}</p>
                                        <p class="text-sm text-gray-400">
                                            {{ \Carbon\Carbon::parse($expense['date'])->format('d/m/Y') }}
                                            @if($expense['is_shared'])
                                                <span class="ml-2 text-white bg-gray-600 px-2 py-0.5 rounded-full text-xs">
                                                    Partagé
                                                </span>
                                            @endif
                                        </p>
                                    </div>
                                    <p class="font-bold text-white">
                                        {{ number_format($expense['amount'], 2, ',', ' ') }} €
                                    </p>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>

        <!-- Parts des dépenses -->
        <div class="gradient-border">
            <div class="bg-dark p-6">
                <h2 class="text-xl font-bold mb-4 flex items-center">
                    <i class="fas fa-chart-pie mr-2"></i>
                    Répartition des dépenses communes
                </h2>
                <div class="grid grid-cols-2 gap-6">
                    @foreach($history->shares_data as $share)
                        <div class="glass-effect p-4 rounded">
                            <div class="flex justify-between items-center mb-2">
                                <span class="flex items-center">
                                    @if($share['email'] === 'lucas.beyer@gmx.fr')
                                        <i class="fas fa-code text-dev mr-2"></i>
                                        <span class="text-dev">{{ $share['name'] }}</span>
                                    @else
                                        <i class="fas fa-lemon text-lemon mr-2"></i>
                                        <span class="text-lemon">{{ $share['name'] }}</span>
                                    @endif
                                </span>
                                <span class="font-bold {{ $share['email'] === 'lucas.beyer@gmx.fr' ? 'text-dev' : 'text-lemon' }}">
                                    {{ number_format($history->total_shared_expenses * $share['share_percentage'] / 100, 2, ',', ' ') }} €
                                </span>
                            </div>
                            <div class="w-full bg-gray-700 rounded-full h-2">
                                <div class="{{ $share['email'] === 'lucas.beyer@gmx.fr' ? 'bg-dev' : 'bg-lemon' }} h-2 rounded-full"
                                    style="width: {{ $share['share_percentage'] }}%">
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
@endsection
