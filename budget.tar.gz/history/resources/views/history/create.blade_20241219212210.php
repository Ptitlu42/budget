@extends('layouts.app')

@section('content')
    <div class="gradient-border">
        <div class="bg-dark p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold flex items-center">
                    <i class="fas fa-plus-circle mr-2 text-white"></i>
                    <span class="text-white">Ajouter un mois à l'historique</span>
                </h1>
                <a href="{{ route('history.index') }}"
                    class="text-white hover:text-gray-300 transition">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Retour à l'historique
                </a>
            </div>

            <form action="{{ route('history.store') }}" method="POST" class="space-y-6">
                @csrf

                <div>
                    <label for="month_year" class="block text-white mb-2">Choisir le mois à archiver</label>
                    <select name="month_year" id="month_year" required
                        class="w-full bg-darker border border-gray-700 rounded px-4 py-2 text-white focus:outline-none focus:border-dev">
                        @foreach($availableMonths as $month)
                            <option value="{{ $month }}">{{ Carbon\Carbon::parse($month)->format('F Y') }}</option>
                        @endforeach
                    </select>
                    <p class="text-gray-400 mt-2">
                        <i class="fas fa-info-circle mr-1"></i>
                        Les revenus et dépenses seront automatiquement récupérés pour le mois sélectionné
                    </p>
                </div>

                <div class="flex justify-end space-x-4">
                    <a href="{{ route('history.index') }}"
                        class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition hover-scale">
                        Annuler
                    </a>
                    <button type="submit"
                        class="bg-dev hover:bg-purple-600 text-white font-bold py-2 px-4 rounded transition hover-scale">
                        Archiver ce mois
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection
