<!DOCTYPE html>
<html lang="fr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        lemon: '#FFD700',     // Couleur citron pour votre chérie
                        cake: '#FF69B4',      // Couleur gâteau pour vous
                        dark: '#1a1a1a',
                        darker: '#0f0f0f'
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-darker text-white min-h-screen">
    <nav class="bg-dark p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="{{ route('dashboard') }}" class="text-white text-2xl font-bold flex items-center">
                <span class="mr-2">Budget</span>
                @if(Auth::check())
                    @if(Auth::user()->email === 'lucas.beyer@gmx.fr')
                        <i class="fas fa-cake-candles text-cake"></i>
                    @else
                        <i class="fas fa-lemon text-lemon"></i>
                    @endif
                @endif
            </a>
            <div class="space-x-4">
                <a href="{{ route('incomes.index') }}" class="text-white hover:text-cake transition">Revenus</a>
                <a href="{{ route('expenses.index') }}" class="text-white hover:text-lemon transition">Dépenses</a>
                <form method="POST" action="{{ route('logout') }}" class="inline">
                    @csrf
                    <button type="submit" class="text-gray-300 hover:text-white transition">Déconnexion</button>
                </form>
            </div>
        </div>
    </nav>

    <main class="container mx-auto p-4">
        @if(session('success'))
            <div class="bg-green-500 text-white p-4 rounded mb-4">
                {{ session('success') }}
            </div>
        @endif

        @yield('content')
    </main>
</body>
</html>
