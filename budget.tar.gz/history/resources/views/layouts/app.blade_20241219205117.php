<!DOCTYPE html>
<html lang="fr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        lemon: '#FFD700',     // Couleur citron pour votre chérie
                        dev: '#9D00FF',       // Couleur ultraviolet pour vous
                        dark: '#1a1a1a',
                        darker: '#0f0f0f'
                    }
                }
            }
        }
    </script>
    <style>
        .glass-effect {
            background: rgba(26, 26, 26, 0.7);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .hover-scale {
            transition: transform 0.2s;
        }

        .hover-scale:hover {
            transform: scale(1.02);
        }

        .gradient-border {
            position: relative;
            border-radius: 0.5rem;
            background: linear-gradient(45deg, #9D00FF, #FFD700);
            padding: 1px;
        }

        .gradient-border > div {
            background: #1a1a1a;
            border-radius: 0.5rem;
        }
    </style>
</head>
<body class="bg-darker text-white min-h-screen">
    <nav class="glass-effect fixed top-0 w-full z-50">
        <div class="container mx-auto flex justify-between items-center p-4">
            <a href="{{ route('dashboard') }}" class="text-white text-2xl font-bold flex items-center hover-scale">
                <span class="mr-2">Budget</span>
                @if(Auth::check())
                    @if(Auth::user()->email === 'lucas.beyer@gmx.fr')
                        <i class="fas fa-code text-dev"></i>
                    @else
                        <i class="fas fa-lemon text-lemon"></i>
                    @endif
                @endif
            </a>
            <div class="space-x-6">
                <a href="{{ route('incomes.index') }}" class="text-white hover:text-dev transition">Revenus</a>
                <a href="{{ route('expenses.index') }}" class="text-white hover:text-lemon transition">Dépenses</a>
                <a href="{{ route('history.index') }}" class="text-white hover:text-gray-300 transition">Historique</a>
                <form method="POST" action="{{ route('logout') }}" class="inline">
                    @csrf
                    <button type="submit" class="text-gray-300 hover:text-white transition">Déconnexion</button>
                </form>
            </div>
        </div>
    </nav>

    <main class="container mx-auto p-4 mt-20">
        @if(session('success'))
            <div class="glass-effect text-white p-4 rounded mb-4 hover-scale">
                {{ session('success') }}
            </div>
        @endif

        @yield('content')
    </main>
</body>
</html>
