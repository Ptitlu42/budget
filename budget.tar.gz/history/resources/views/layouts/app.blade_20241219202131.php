<!DOCTYPE html>
<html lang="fr" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Budget</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#FF00FF',
                        secondary: '#00FFFF',
                        dark: '#1a1a1a',
                        darker: '#0f0f0f'
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-darker text-white min-h-screen">
    <nav class="bg-dark p-4">
        <div class="container mx-auto flex justify-between items-center">
            <a href="{{ route('dashboard') }}" class="text-primary text-2xl font-bold">Budget</a>
            <div class="space-x-4">
                <a href="{{ route('incomes.index') }}" class="text-secondary hover:text-primary transition">Revenus</a>
                <a href="{{ route('expenses.index') }}" class="text-secondary hover:text-primary transition">Dépenses</a>
                <form method="POST" action="{{ route('logout') }}" class="inline">
                    @csrf
                    <button type="submit" class="text-secondary hover:text-primary transition">Déconnexion</button>
                </form>
            </div>
        </div>
    </nav>

    <main class="container mx-auto p-4">
        @if(session('success'))
            <div class="bg-green-500 text-white p-4 rounded mb-4">
                {{ session('success') }}
            </div>
        @endif

        @yield('content')
    </main>
</body>
</html>
