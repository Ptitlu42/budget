@extends('layouts.app')

@section('content')
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Carte des revenus -->
        <div class="bg-dark p-6 rounded-lg shadow-lg">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold flex items-center">
                    @if(Auth::user()->email === 'lucas.beyer@gmx.fr')
                        <i class="fas fa-cake-candles text-cake mr-2"></i>
                        <span class="text-cake">Mes revenus du mois</span>
                    @else
                        <i class="fas fa-lemon text-lemon mr-2"></i>
                        <span class="text-lemon">Mes revenus du mois</span>
                    @endif
                </h2>
                <a href="{{ route('incomes.create') }}"
                    class="{{ Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-cake' : 'text-lemon' }} hover:opacity-75 transition flex items-center">
                    <i class="fas fa-plus-circle mr-1"></i>
                    Ajouter
                </a>
            </div>

            @php
                $monthlyIncomes = App\Models\Income::whereMonth('date', now()->month)
                    ->whereYear('date', now()->year)
                    ->where('user_id', Auth::id())
                    ->get();
                $totalMonthlyIncome = $monthlyIncomes->sum('amount');
            @endphp

            <div class="grid grid-cols-2 gap-4 mb-4">
                <div class="bg-darker p-4 rounded">
                    <p class="{{ Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-cake' : 'text-lemon' }} mb-1 flex items-center">
                        <i class="fas fa-euro-sign mr-2"></i>
                        Total
                    </p>
                    <p class="text-2xl font-bold text-white">{{ number_format($totalMonthlyIncome, 2, ',', ' ') }} €</p>
                </div>
                <div class="bg-darker p-4 rounded">
                    <p class="{{ Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-cake' : 'text-lemon' }} mb-1 flex items-center">
                        <i class="fas fa-list mr-2"></i>
                        Nombre d'entrées
                    </p>
                    <p class="text-2xl font-bold text-white">{{ $monthlyIncomes->count() }}</p>
                </div>
            </div>

            <div class="space-y-2">
                @foreach($monthlyIncomes->sortByDesc('date')->take(3) as $income)
                    <div class="bg-darker p-3 rounded flex justify-between items-center">
                        <div>
                            <p class="text-white flex items-center">
                                @switch($income->type)
                                    @case('salary')
                                        <i class="fas fa-money-bill-wave mr-2 {{ Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-cake' : 'text-lemon' }}"></i>
                                        @break
                                    @case('aid')
                                        <i class="fas fa-hand-holding-heart mr-2 {{ Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-cake' : 'text-lemon' }}"></i>
                                        @break
                                    @default
                                        <i class="fas fa-plus-circle mr-2 {{ Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-cake' : 'text-lemon' }}"></i>
                                @endswitch
                                {{ $income->description }}
                            </p>
                            <p class="text-sm text-gray-400">{{ $income->date->format('d/m/Y') }}</p>
                        </div>
                        <p class="font-bold {{ Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-cake' : 'text-lemon' }}">
                            {{ number_format($income->amount, 2, ',', ' ') }} €
                        </p>
                    </div>
                @endforeach
            </div>
        </div>

        <!-- Carte des dépenses -->
        <div class="bg-dark p-6 rounded-lg shadow-lg">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold text-white flex items-center">
                    <i class="fas fa-wallet mr-2"></i>
                    Dépenses du mois
                </h2>
                <a href="{{ route('expenses.create') }}" class="text-white hover:opacity-75 transition flex items-center">
                    <i class="fas fa-plus-circle mr-1"></i>
                    Ajouter
                </a>
            </div>

            @php
                $monthlyExpenses = App\Models\Expense::whereMonth('date', now()->month)
                    ->whereYear('date', now()->year)
                    ->get();
                $totalMonthlyExpense = $monthlyExpenses->sum('amount');
            @endphp

            <div class="grid grid-cols-2 gap-4 mb-4">
                <div class="bg-darker p-4 rounded">
                    <p class="text-white mb-1 flex items-center">
                        <i class="fas fa-euro-sign mr-2"></i>
                        Total
                    </p>
                    <p class="text-2xl font-bold text-white">{{ number_format($totalMonthlyExpense, 2, ',', ' ') }} €</p>
                </div>
                <div class="bg-darker p-4 rounded">
                    <p class="text-white mb-1 flex items-center">
                        <i class="fas fa-list mr-2"></i>
                        Nombre de dépenses
                    </p>
                    <p class="text-2xl font-bold text-white">{{ $monthlyExpenses->count() }}</p>
                </div>
            </div>

            <div class="space-y-2">
                @foreach($monthlyExpenses->sortByDesc('date')->take(3) as $expense)
                    <div class="bg-darker p-3 rounded flex justify-between items-center">
                        <div>
                            <p class="text-white flex items-center">
                                @switch($expense->type)
                                    @case('rent')
                                        <i class="fas fa-home mr-2 text-white"></i>
                                        @break
                                    @case('insurance')
                                        <i class="fas fa-shield-alt mr-2 text-white"></i>
                                        @break
                                    @case('utilities')
                                        <i class="fas fa-bolt mr-2 text-white"></i>
                                        @break
                                    @case('groceries')
                                        <i class="fas fa-shopping-cart mr-2 text-white"></i>
                                        @break
                                    @default
                                        <i class="fas fa-plus-circle mr-2 text-white"></i>
                                @endswitch
                                {{ $expense->description }}
                            </p>
                            <p class="text-sm text-gray-400">{{ $expense->date->format('d/m/Y') }}</p>
                        </div>
                        <p class="font-bold text-white">{{ number_format($expense->amount, 2, ',', ' ') }} €</p>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection
