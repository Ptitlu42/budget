@extends('layouts.app')

@section('content')
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Liste des dépenses -->
        <div class="md:col-span-2 bg-dark p-6 rounded-lg shadow-lg">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold flex items-center">
                    <i class="fas fa-wallet text-white mr-2"></i>
                    <span class="text-white">Dépenses communes</span>
                </h1>
                <a href="{{ route('expenses.create') }}" class="bg-white hover:bg-gray-100 text-dark font-bold py-2 px-4 rounded transition">
                    Ajouter une dépense
                </a>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="text-white border-b border-gray-700">
                            <th class="py-2 px-4 text-left">Date</th>
                            <th class="py-2 px-4 text-left">Description</th>
                            <th class="py-2 px-4 text-left">Type</th>
                            <th class="py-2 px-4 text-right">Montant</th>
                            <th class="py-2 px-4 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($expenses as $expense)
                            <tr class="border-b border-gray-700 hover:bg-gray-800">
                                <td class="py-2 px-4">{{ $expense->date->format('d/m/Y') }}</td>
                                <td class="py-2 px-4">{{ $expense->description }}</td>
                                <td class="py-2 px-4">
                                    @switch($expense->type)
                                        @case('rent')
                                            <span class="flex items-center">
                                                <i class="fas fa-home mr-2 text-white"></i>
                                                Loyer
                                            </span>
                                            @break
                                        @case('insurance')
                                            <span class="flex items-center">
                                                <i class="fas fa-shield-alt mr-2 text-white"></i>
                                                Assurance
                                            </span>
                                            @break
                                        @case('utilities')
                                            <span class="flex items-center">
                                                <i class="fas fa-bolt mr-2 text-white"></i>
                                                Charges
                                            </span>
                                            @break
                                        @case('groceries')
                                            <span class="flex items-center">
                                                <i class="fas fa-shopping-cart mr-2 text-white"></i>
                                                Courses
                                            </span>
                                            @break
                                        @default
                                            <span class="flex items-center">
                                                <i class="fas fa-plus-circle mr-2 text-white"></i>
                                                Autre
                                            </span>
                                    @endswitch
                                </td>
                                <td class="py-2 px-4 text-right font-bold text-white">
                                    {{ number_format($expense->amount, 2, ',', ' ') }} €
                                </td>
                                <td class="py-2 px-4 text-center">
                                    <a href="{{ route('expenses.edit', $expense) }}" class="text-white hover:text-gray-300 mr-2">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="{{ route('expenses.destroy', $expense) }}" method="POST" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-500 hover:text-red-700"
                                            onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette dépense ?')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Répartition des dépenses -->
        <div class="bg-dark p-6 rounded-lg shadow-lg">
            <h2 class="text-xl font-bold text-white mb-4 flex items-center">
                <i class="fas fa-chart-pie mr-2"></i>
                Répartition des dépenses
            </h2>

            <div class="space-y-4">
                @foreach($shares as $share)
                    <div class="bg-darker p-4 rounded">
                        <div class="flex justify-between items-center mb-2">
                            <span class="flex items-center">
                                @if($share->email === 'lucas.beyer@gmx.fr')
                                    <i class="fas fa-cake-candles text-cake mr-2"></i>
                                    <span class="text-cake">{{ $share->name }}</span>
                                @else
                                    <i class="fas fa-lemon text-lemon mr-2"></i>
                                    <span class="text-lemon">{{ $share->name }}</span>
                                @endif
                            </span>
                            <span class="font-bold {{ $share->email === 'lucas.beyer@gmx.fr' ? 'text-cake' : 'text-lemon' }}">
                                {{ number_format($share->share_percentage, 1) }}%
                            </span>
                        </div>
                        <div class="w-full bg-gray-700 rounded-full h-2">
                            <div class="{{ $share->email === 'lucas.beyer@gmx.fr' ? 'bg-cake' : 'bg-lemon' }} h-2 rounded-full"
                                style="width: {{ $share->share_percentage }}%">
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="mt-6 p-4 bg-darker rounded">
                <h3 class="text-white mb-2 flex items-center">
                    <i class="fas fa-euro-sign mr-2"></i>
                    Total des dépenses communes
                </h3>
                <p class="text-2xl font-bold text-white">
                    {{ number_format($expenses->where('is_shared', true)->sum('amount'), 2, ',', ' ') }} €
                </p>
            </div>
        </div>
    </div>
@endsection
