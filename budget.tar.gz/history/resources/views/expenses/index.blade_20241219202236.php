@extends('layouts.app')

@section('content')
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Liste des dépenses -->
        <div class="md:col-span-2 bg-dark p-6 rounded-lg shadow-lg">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-primary">Dépenses communes</h1>
                <a href="{{ route('expenses.create') }}" class="bg-secondary hover:bg-primary text-dark font-bold py-2 px-4 rounded transition">
                    Ajouter une dépense
                </a>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="text-secondary border-b border-gray-700">
                            <th class="py-2 px-4 text-left">Date</th>
                            <th class="py-2 px-4 text-left">Description</th>
                            <th class="py-2 px-4 text-left">Type</th>
                            <th class="py-2 px-4 text-right">Montant</th>
                            <th class="py-2 px-4 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($expenses as $expense)
                            <tr class="border-b border-gray-700 hover:bg-gray-800">
                                <td class="py-2 px-4">{{ $expense->date->format('d/m/Y') }}</td>
                                <td class="py-2 px-4">{{ $expense->description }}</td>
                                <td class="py-2 px-4">
                                    @switch($expense->type)
                                        @case('rent')
                                            Loyer
                                            @break
                                        @case('insurance')
                                            Assurance
                                            @break
                                        @case('utilities')
                                            Charges
                                            @break
                                        @case('groceries')
                                            Courses
                                            @break
                                        @default
                                            Autre
                                    @endswitch
                                </td>
                                <td class="py-2 px-4 text-right">{{ number_format($expense->amount, 2, ',', ' ') }} €</td>
                                <td class="py-2 px-4 text-center">
                                    <a href="{{ route('expenses.edit', $expense) }}" class="text-secondary hover:text-primary mr-2">
                                        Modifier
                                    </a>
                                    <form action="{{ route('expenses.destroy', $expense) }}" method="POST" class="inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="text-red-500 hover:text-red-700" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette dépense ?')">
                                            Supprimer
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Répartition des dépenses -->
        <div class="bg-dark p-6 rounded-lg shadow-lg">
            <h2 class="text-xl font-bold text-primary mb-4">Répartition des dépenses</h2>

            <div class="space-y-4">
                @foreach($shares as $share)
                    <div class="bg-darker p-4 rounded">
                        <div class="flex justify-between items-center mb-2">
                            <span class="text-secondary">{{ $share->name }}</span>
                            <span class="text-white font-bold">{{ number_format($share->share_percentage, 1) }}%</span>
                        </div>
                        <div class="w-full bg-gray-700 rounded-full h-2">
                            <div class="bg-secondary h-2 rounded-full" style="width: {{ $share->share_percentage }}%"></div>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="mt-6 p-4 bg-darker rounded">
                <h3 class="text-secondary mb-2">Total des dépenses communes</h3>
                <p class="text-2xl font-bold text-white">
                    {{ number_format($expenses->where('is_shared', true)->sum('amount'), 2, ',', ' ') }} €
                </p>
            </div>
        </div>
    </div>
@endsection
