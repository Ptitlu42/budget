@extends('layouts.app')

@section('content')
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Carte des revenus -->
        <div class="bg-dark p-6 rounded-lg shadow-lg">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold text-primary">Revenus du mois</h2>
                <a href="{{ route('incomes.create') }}" class="text-secondary hover:text-primary transition">
                    Ajouter un revenu
                </a>
            </div>

            @php
                $monthlyIncomes = App\Models\Income::whereMonth('date', now()->month)
                    ->whereYear('date', now()->year)
                    ->get();
                $totalMonthlyIncome = $monthlyIncomes->sum('amount');
            @endphp

            <div class="grid grid-cols-2 gap-4 mb-4">
                <div class="bg-darker p-4 rounded">
                    <p class="text-secondary mb-1">Total</p>
                    <p class="text-2xl font-bold text-white">{{ number_format($totalMonthlyIncome, 2, ',', ' ') }} €</p>
                </div>
                <div class="bg-darker p-4 rounded">
                    <p class="text-secondary mb-1">Nombre d'entrées</p>
                    <p class="text-2xl font-bold text-white">{{ $monthlyIncomes->count() }}</p>
                </div>
            </div>

            <div class="space-y-2">
                @foreach($monthlyIncomes->sortByDesc('date')->take(3) as $income)
                    <div class="bg-darker p-3 rounded flex justify-between items-center">
                        <div>
                            <p class="text-white">{{ $income->description }}</p>
                            <p class="text-sm text-gray-400">{{ $income->date->format('d/m/Y') }}</p>
                        </div>
                        <p class="text-secondary font-bold">{{ number_format($income->amount, 2, ',', ' ') }} €</p>
                    </div>
                @endforeach
            </div>
        </div>

        <!-- Carte des dépenses -->
        <div class="bg-dark p-6 rounded-lg shadow-lg">
            <div class="flex justify-between items-center mb-6">
                <h2 class="text-xl font-bold text-primary">Dépenses du mois</h2>
                <a href="{{ route('expenses.create') }}" class="text-secondary hover:text-primary transition">
                    Ajouter une dépense
                </a>
            </div>

            @php
                $monthlyExpenses = App\Models\Expense::whereMonth('date', now()->month)
                    ->whereYear('date', now()->year)
                    ->get();
                $totalMonthlyExpense = $monthlyExpenses->sum('amount');
            @endphp

            <div class="grid grid-cols-2 gap-4 mb-4">
                <div class="bg-darker p-4 rounded">
                    <p class="text-secondary mb-1">Total</p>
                    <p class="text-2xl font-bold text-white">{{ number_format($totalMonthlyExpense, 2, ',', ' ') }} €</p>
                </div>
                <div class="bg-darker p-4 rounded">
                    <p class="text-secondary mb-1">Nombre de dépenses</p>
                    <p class="text-2xl font-bold text-white">{{ $monthlyExpenses->count() }}</p>
                </div>
            </div>

            <div class="space-y-2">
                @foreach($monthlyExpenses->sortByDesc('date')->take(3) as $expense)
                    <div class="bg-darker p-3 rounded flex justify-between items-center">
                        <div>
                            <p class="text-white">{{ $expense->description }}</p>
                            <p class="text-sm text-gray-400">{{ $expense->date->format('d/m/Y') }}</p>
                        </div>
                        <p class="text-secondary font-bold">{{ number_format($expense->amount, 2, ',', ' ') }} €</p>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection
