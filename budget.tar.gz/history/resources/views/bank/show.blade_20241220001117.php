@extends('layouts.app')

@section('content')
    <div class="gradient-border">
        <div class="bg-dark p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold flex items-center">
                    <i class="fas fa-university mr-2 text-white"></i>
                    <span class="text-white">{{ $account->account_name }}</span>
                </h1>
                <div class="flex items-center space-x-4">
                    <form action="{{ route('bank.refresh', $account) }}" method="POST">
                        @csrf
                        <button type="submit" class="text-dev hover:text-purple-400 transition">
                            <i class="fas fa-sync-alt mr-2"></i>
                            Actualiser
                        </button>
                    </form>
                    <a href="{{ route('bank.index') }}"
                        class="text-white hover:text-gray-300 transition">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Retour aux comptes
                    </a>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div class="gradient-border hover-scale">
                    <div class="bg-dark p-6">
                        <h3 class="text-lg font-semibold mb-2">Solde disponible</h3>
                        <p class="text-2xl font-bold {{ $balances['balances'][0]['balanceAmount']['amount'] >= 0 ? 'text-green-500' : 'text-red-500' }}">
                            {{ number_format($balances['balances'][0]['balanceAmount']['amount'], 2, ',', ' ') }} {{ $balances['balances'][0]['balanceAmount']['currency'] }}
                        </p>
                    </div>
                </div>
                <div class="gradient-border hover-scale">
                    <div class="bg-dark p-6">
                        <h3 class="text-lg font-semibold mb-2">Solde comptable</h3>
                        <p class="text-2xl font-bold {{ $balances['balances'][1]['balanceAmount']['amount'] ?? 0 >= 0 ? 'text-green-500' : 'text-red-500' }}">
                            {{ number_format($balances['balances'][1]['balanceAmount']['amount'] ?? $balances['balances'][0]['balanceAmount']['amount'], 2, ',', ' ') }} {{ $balances['balances'][0]['balanceAmount']['currency'] }}
                        </p>
                    </div>
                </div>
                <div class="gradient-border hover-scale">
                    <div class="bg-dark p-6">
                        <h3 class="text-lg font-semibold mb-2">Dernière mise à jour</h3>
                        <p class="text-2xl font-bold text-white">
                            {{ \Carbon\Carbon::parse($balances['balances'][0]['referenceDate'])->format('d/m/Y H:i') }}
                        </p>
                    </div>
                </div>
            </div>

            <div class="gradient-border">
                <div class="bg-dark p-6">
                    <h2 class="text-xl font-bold text-white mb-4">Transactions récentes</h2>
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead>
                                <tr class="text-dev border-b border-gray-700">
                                    <th class="py-2 px-4 text-left">Date</th>
                                    <th class="py-2 px-4 text-left">Description</th>
                                    <th class="py-2 px-4 text-right">Montant</th>
                                    <th class="py-2 px-4 text-center">Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($transactions['transactions']['booked'] as $transaction)
                                    <tr class="border-b border-gray-700 hover:bg-gray-800">
                                        <td class="py-2 px-4">
                                            {{ \Carbon\Carbon::parse($transaction['bookingDate'])->format('d/m/Y') }}
                                        </td>
                                        <td class="py-2 px-4">
                                            {{ $transaction['remittanceInformationUnstructured'] ?? $transaction['additionalInformation'] ?? 'Transaction' }}
                                        </td>
                                        <td class="py-2 px-4 text-right font-bold {{ $transaction['transactionAmount']['amount'] >= 0 ? 'text-green-500' : 'text-red-500' }}">
                                            {{ number_format($transaction['transactionAmount']['amount'], 2, ',', ' ') }} {{ $transaction['transactionAmount']['currency'] }}
                                        </td>
                                        <td class="py-2 px-4 text-center">
                                            <span class="px-2 py-1 text-xs rounded {{ $transaction['transactionAmount']['amount'] >= 0 ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500' }}">
                                                {{ $transaction['transactionAmount']['amount'] >= 0 ? 'Crédit' : 'Débit' }}
                                            </span>
                                        </td>
                                    </tr>
                                @endforeach

                                @foreach($transactions['transactions']['pending'] ?? [] as $transaction)
                                    <tr class="border-b border-gray-700 hover:bg-gray-800 opacity-70">
                                        <td class="py-2 px-4">
                                            {{ \Carbon\Carbon::parse($transaction['bookingDate'])->format('d/m/Y') }}
                                        </td>
                                        <td class="py-2 px-4">
                                            {{ $transaction['remittanceInformationUnstructured'] ?? $transaction['additionalInformation'] ?? 'Transaction' }}
                                        </td>
                                        <td class="py-2 px-4 text-right font-bold {{ $transaction['transactionAmount']['amount'] >= 0 ? 'text-green-500' : 'text-red-500' }}">
                                            {{ number_format($transaction['transactionAmount']['amount'], 2, ',', ' ') }} {{ $transaction['transactionAmount']['currency'] }}
                                        </td>
                                        <td class="py-2 px-4 text-center">
                                            <span class="px-2 py-1 bg-yellow-500/20 text-yellow-500 text-xs rounded">
                                                En attente
                                            </span>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
