@extends('layouts.app')

@section('content')
    <div class="gradient-border">
        <div class="bg-dark p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold flex items-center">
                    <i class="fas fa-plug mr-2 text-white"></i>
                    <span class="text-white">Connecter un compte bancaire</span>
                </h1>
                <a href="{{ route('bank.index') }}"
                    class="text-white hover:text-gray-300 transition">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Retour aux comptes
                </a>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                @foreach($banks as $bank)
                    @if($bank['id'] === 'CMUT_FR')
                        <form action="{{ route('bank.initiate') }}" method="POST">
                            @csrf
                            <input type="hidden" name="bank_id" value="{{ $bank['id'] }}">
                            <button type="submit" class="w-full">
                                <div class="gradient-border hover-scale h-full">
                                    <div class="bg-dark p-6 text-center h-full">
                                        <img src="{{ $bank['logo'] }}" alt="{{ $bank['name'] }}" class="w-24 h-24 mx-auto mb-4">
                                        <h2 class="text-xl font-bold text-white mb-2">{{ $bank['name'] }}</h2>
                                        <p class="text-gray-400">{{ $bank['bic'] }}</p>
                                    </div>
                                </div>
                            </button>
                        </form>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
@endsection
