@extends('layouts.app')

@section('content')
    <div class="gradient-border">
        <div class="bg-dark p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold flex items-center">
                    <i class="fas fa-university mr-2 text-white"></i>
                    <span class="text-white">Mes Comptes Bancaires</span>
                </h1>
                <a href="{{ route('bank.connect') }}"
                    class="bg-dev hover:bg-purple-600 text-white font-bold py-2 px-4 rounded transition hover-scale">
                    <i class="fas fa-plus mr-2"></i>
                    Connecter un compte
                </a>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                @forelse($accounts as $account)
                    <div class="gradient-border hover-scale">
                        <div class="bg-dark p-6">
                            <div class="flex justify-between items-center mb-4">
                                <div>
                                    <h2 class="text-xl font-bold text-white">{{ $account->account_name }}</h2>
                                    <p class="text-gray-400">{{ ucfirst($account->account_type) }}</p>
                                </div>
                                <div class="flex items-center space-x-4">
                                    <form action="{{ route('bank.refresh', $account) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="text-dev hover:text-purple-400 transition">
                                            <i class="fas fa-sync-alt"></i>
                                        </button>
                                    </form>
                                    <a href="{{ route('bank.show', $account) }}" class="text-dev hover:text-purple-400 transition">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="glass-effect p-4 rounded">
                                <div class="flex justify-between items-center">
                                    <span class="text-gray-400">Solde actuel</span>
                                    <span class="text-2xl font-bold {{ $account->balance >= 0 ? 'text-green-500' : 'text-red-500' }}">
                                        {{ number_format($account->balance, 2, ',', ' ') }} {{ $account->currency }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="col-span-2">
                        <div class="glass-effect p-6 text-center">
                            <p class="text-gray-400 mb-4">Aucun compte bancaire connecté</p>
                            <a href="{{ route('bank.connect') }}"
                                class="bg-dev hover:bg-purple-600 text-white font-bold py-2 px-4 rounded transition hover-scale inline-block">
                                <i class="fas fa-plus mr-2"></i>
                                Connecter mon premier compte
                            </a>
                        </div>
                    </div>
                @endforelse
            </div>
        </div>
    </div>
@endsection
