@extends('layouts.app')

@section('content')
    <div class="bg-dark p-6 rounded-lg shadow-lg max-w-2xl mx-auto">
        <h1 class="text-2xl font-bold text-primary mb-6">Ajouter un revenu</h1>

        <form action="{{ route('incomes.store') }}" method="POST">
            @csrf

            <div class="mb-4">
                <label for="description" class="block text-secondary mb-2">Description</label>
                <input type="text" name="description" id="description"
                    class="w-full bg-darker border border-gray-700 rounded p-2 text-white focus:border-secondary focus:outline-none"
                    value="{{ old('description') }}" required>
                @error('description')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-4">
                <label for="amount" class="block text-secondary mb-2">Montant (€)</label>
                <input type="number" name="amount" id="amount" step="0.01" min="0"
                    class="w-full bg-darker border border-gray-700 rounded p-2 text-white focus:border-secondary focus:outline-none"
                    value="{{ old('amount') }}" required>
                @error('amount')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-4">
                <label for="type" class="block text-secondary mb-2">Type</label>
                <select name="type" id="type"
                    class="w-full bg-darker border border-gray-700 rounded p-2 text-white focus:border-secondary focus:outline-none">
                    <option value="salary" {{ old('type') == 'salary' ? 'selected' : '' }}>Salaire</option>
                    <option value="aid" {{ old('type') == 'aid' ? 'selected' : '' }}>Aide</option>
                    <option value="other" {{ old('type') == 'other' ? 'selected' : '' }}>Autre</option>
                </select>
                @error('type')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-6">
                <label for="date" class="block text-secondary mb-2">Date</label>
                <input type="date" name="date" id="date"
                    class="w-full bg-darker border border-gray-700 rounded p-2 text-white focus:border-secondary focus:outline-none"
                    value="{{ old('date', date('Y-m-d')) }}" required>
                @error('date')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="flex justify-end space-x-4">
                <a href="{{ route('incomes.index') }}"
                    class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition">
                    Annuler
                </a>
                <button type="submit"
                    class="bg-secondary hover:bg-primary text-dark font-bold py-2 px-4 rounded transition">
                    Ajouter
                </button>
            </div>
        </form>
    </div>
@endsection
