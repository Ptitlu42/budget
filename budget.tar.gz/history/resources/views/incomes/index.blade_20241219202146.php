@extends('layouts.app')

@section('content')
    <div class="bg-dark p-6 rounded-lg shadow-lg">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold text-primary">Mes Revenus</h1>
            <a href="{{ route('incomes.create') }}" class="bg-secondary hover:bg-primary text-dark font-bold py-2 px-4 rounded transition">
                Ajouter un revenu
            </a>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="text-secondary border-b border-gray-700">
                        <th class="py-2 px-4 text-left">Date</th>
                        <th class="py-2 px-4 text-left">Description</th>
                        <th class="py-2 px-4 text-left">Type</th>
                        <th class="py-2 px-4 text-right">Montant</th>
                        <th class="py-2 px-4 text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($incomes as $income)
                        <tr class="border-b border-gray-700 hover:bg-gray-800">
                            <td class="py-2 px-4">{{ $income->date->format('d/m/Y') }}</td>
                            <td class="py-2 px-4">{{ $income->description }}</td>
                            <td class="py-2 px-4">
                                @switch($income->type)
                                    @case('salary')
                                        Salaire
                                        @break
                                    @case('aid')
                                        Aide
                                        @break
                                    @default
                                        Autre
                                @endswitch
                            </td>
                            <td class="py-2 px-4 text-right">{{ number_format($income->amount, 2, ',', ' ') }} €</td>
                            <td class="py-2 px-4 text-center">
                                <a href="{{ route('incomes.edit', $income) }}" class="text-secondary hover:text-primary mr-2">
                                    Modifier
                                </a>
                                <form action="{{ route('incomes.destroy', $income) }}" method="POST" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-500 hover:text-red-700" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce revenu ?')">
                                        Supprimer
                                    </button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
