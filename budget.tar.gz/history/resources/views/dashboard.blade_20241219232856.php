@extends('layouts.app')

@section('content')
    <!-- Statistiques globales -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div class="gradient-border">
            <div class="bg-dark p-6">
                <h3 class="text-white mb-2 flex items-center">
                    <i class="fas fa-euro-sign mr-2"></i>
                    Revenus Totaux
                </h3>
                <p class="text-2xl font-bold text-white">
                    {{ number_format(App\Models\Income::sum('amount'), 2, ',', ' ') }} €
                </p>
            </div>
        </div>
        <div class="gradient-border">
            <div class="bg-dark p-6">
                <h3 class="text-white mb-2 flex items-center">
                    <i class="fas fa-wallet mr-2"></i>
                    Dépenses Totales
                </h3>
                <p class="text-2xl font-bold text-white">
                    {{ number_format(App\Models\Expense::sum('amount'), 2, ',', ' ') }} €
                </p>
            </div>
        </div>
        <div class="gradient-border">
            <div class="bg-dark p-6">
                <h3 class="text-white mb-2 flex items-center">
                    <i class="fas fa-hand-holding-euro mr-2"></i>
                    Dépenses Communes
                </h3>
                <p class="text-2xl font-bold text-white">
                    {{ number_format(App\Models\Expense::where('is_shared', true)->sum('amount'), 2, ',', ' ') }} €
                </p>
            </div>
        </div>
        <div class="gradient-border">
            <div class="bg-dark p-6">
                <h3 class="text-white mb-2 flex items-center">
                    <i class="fas fa-user-tag mr-2"></i>
                    Dépenses Individuelles
                </h3>
                <p class="text-2xl font-bold text-white">
                    {{ number_format(App\Models\Expense::where('is_shared', false)->sum('amount'), 2, ',', ' ') }} €
                </p>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <!-- Revenus par personne -->
        <div class="gradient-border">
            <div class="bg-dark p-6">
                <h2 class="text-xl font-bold text-white mb-4 flex items-center">
                    <i class="fas fa-chart-bar mr-2"></i>
                    Revenus par personne
                </h2>
                @php
                    $users = DB::table('incomes')
                        ->join('users', 'incomes.user_id', '=', 'users.id')
                        ->select('users.name', 'users.email', DB::raw('SUM(amount) as total_income'))
                        ->groupBy('users.id', 'users.name', 'users.email')
                        ->get();
                @endphp
                <div class="space-y-4">
                    @foreach($users as $user)
                        <div class="glass-effect p-4 rounded">
                            <div class="flex justify-between items-center mb-2">
                                <span class="flex items-center">
                                    @if($user->email === 'lucas.beyer@gmx.fr')
                                        <i class="fas fa-code text-dev mr-2"></i>
                                        <span class="text-dev">{{ $user->name }}</span>
                                    @else
                                        <i class="fas fa-lemon text-lemon mr-2"></i>
                                        <span class="text-lemon">{{ $user->name }}</span>
                                    @endif
                                </span>
                                <span class="font-bold {{ $user->email === 'lucas.beyer@gmx.fr' ? 'text-dev' : 'text-lemon' }}">
                                    {{ number_format($user->total_income, 2, ',', ' ') }} €
                                </span>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>

        <!-- Graphique camembert -->
        <div class="gradient-border">
            <div class="bg-dark p-6">
                <h2 class="text-xl font-bold text-white mb-4 flex items-center">
                    <i class="fas fa-chart-pie mr-2"></i>
                    Répartition des revenus
                </h2>
                <canvas id="revenusChart" class="w-full"></canvas>
            </div>
        </div>
    </div>

    <!-- Répartition des dépenses -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="gradient-border">
            <div class="bg-dark p-6">
                <h2 class="text-xl font-bold text-white mb-4 flex items-center">
                    <i class="fas fa-calculator mr-2"></i>
                    Part des dépenses communes
                </h2>
                @php
                    $totalIncomes = App\Models\Income::sum('amount');
                    $shares = DB::table('incomes')
                        ->join('users', 'incomes.user_id', '=', 'users.id')
                        ->select('users.name', 'users.email', DB::raw('SUM(amount) as total_income'))
                        ->groupBy('users.id', 'users.name', 'users.email')
                        ->get()
                        ->map(function ($user) use ($totalIncomes) {
                            $user->share_percentage = ($totalIncomes > 0) ? ($user->total_income / $totalIncomes) * 100 : 0;
                            return $user;
                        });
                    $totalSharedExpenses = App\Models\Expense::where('is_shared', true)->sum('amount');
                @endphp
                <div class="space-y-4">
                    @foreach($shares as $share)
                        <div class="glass-effect p-4 rounded">
                            <div class="flex justify-between items-center mb-2">
                                <span class="flex items-center">
                                    @if($share->email === 'lucas.beyer@gmx.fr')
                                        <i class="fas fa-code text-dev mr-2"></i>
                                        <span class="text-dev">{{ $share->name }}</span>
                                    @else
                                        <i class="fas fa-lemon text-lemon mr-2"></i>
                                        <span class="text-lemon">{{ $share->name }}</span>
                                    @endif
                                </span>
                                <span class="font-bold {{ $share->email === 'lucas.beyer@gmx.fr' ? 'text-dev' : 'text-lemon' }}">
                                    {{ number_format(($totalSharedExpenses * $share->share_percentage / 100), 2, ',', ' ') }} €
                                </span>
                            </div>
                            <div class="w-full bg-gray-700 rounded-full h-2">
                                <div class="{{ $share->email === 'lucas.beyer@gmx.fr' ? 'bg-dev' : 'bg-lemon' }} h-2 rounded-full"
                                    style="width: {{ $share->share_percentage }}%">
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>

        <div class="gradient-border">
            <div class="bg-dark p-6">
                <h2 class="text-xl font-bold text-white mb-4 flex items-center">
                    <i class="fas fa-tags mr-2"></i>
                    Dépenses par catégorie
                </h2>
                <canvas id="depensesChart" class="w-full"></canvas>
            </div>
        </div>
    </div>

    <!-- Scripts pour les graphiques -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Données pour le graphique des revenus
        const revenusData = {
            labels: [
                @foreach($users as $user)
                    "{{ $user->name }}",
                @endforeach
            ],
            datasets: [{
                data: [
                    @foreach($users as $user)
                        {{ $user->total_income }},
                    @endforeach
                ],
                backgroundColor: [
                    '#9D00FF', // Couleur dev (ultraviolet)
                    '#FFD700'  // Couleur citron
                ]
            }]
        };

        // Configuration du graphique des revenus
        const revenusConfig = {
            type: 'pie',
            data: revenusData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: 'white'
                        }
                    }
                }
            }
        };

        // Création du graphique des revenus
        new Chart(
            document.getElementById('revenusChart'),
            revenusConfig
        );

        // Données pour le graphique des dépenses
        const depensesData = {
            labels: ['Loyer', 'Assurance', 'Charges', 'Courses', 'Autre'],
            datasets: [{
                data: [
                    {{ App\Models\Expense::where('type', 'rent')->sum('amount') }},
                    {{ App\Models\Expense::where('type', 'insurance')->sum('amount') }},
                    {{ App\Models\Expense::where('type', 'utilities')->sum('amount') }},
                    {{ App\Models\Expense::where('type', 'groceries')->sum('amount') }},
                    {{ App\Models\Expense::where('type', 'other')->sum('amount') }}
                ],
                backgroundColor: [
                    '#9D00FF', // Ultraviolet
                    '#FFD700', // Citron
                    '#00FF00', // Vert vif
                    '#FF00FF', // Magenta
                    '#00FFFF'  // Cyan
                ]
            }]
        };

        // Configuration du graphique des dépenses
        const depensesConfig = {
            type: 'pie',
            data: depensesData,
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: 'white'
                        }
                    }
                }
            }
        };

        // Création du graphique des dépenses
        new Chart(
            document.getElementById('depensesChart'),
            depensesConfig
        );
    </script>
@endsection
