<?php $__env->startSection('content'); ?>
    <div class="gradient-border">
        <div class="bg-dark p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold flex items-center">
                    <i class="fas fa-edit mr-2 text-white"></i>
                    <span class="text-white">Modifier une dépense</span>
                </h1>
                <a href="<?php echo e(route('expenses.index')); ?>"
                    class="text-white hover:text-gray-300 transition">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Retour aux dépenses
                </a>
            </div>

            <form action="<?php echo e(route('expenses.update', $expense)); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="grid grid-cols-2 gap-6">
                    <div>
                        <label for="description" class="block text-white mb-2">Description</label>
                        <input type="text" name="description" id="description" required
                            class="w-full bg-darker border border-gray-700 rounded px-4 py-2 text-white focus:outline-none focus:border-dev"
                            value="<?php echo e($expense->description); ?>">
                    </div>

                    <div>
                        <label for="amount" class="block text-white mb-2">Montant</label>
                        <input type="number" step="0.01" name="amount" id="amount" required
                            class="w-full bg-darker border border-gray-700 rounded px-4 py-2 text-white focus:outline-none focus:border-dev"
                            value="<?php echo e($expense->amount); ?>">
                    </div>

                    <div>
                        <label for="type" class="block text-white mb-2">Type</label>
                        <select name="type" id="type" required
                            class="w-full bg-darker border border-gray-700 rounded px-4 py-2 text-white focus:outline-none focus:border-dev">
                            <option value="rent" <?php echo e($expense->type === 'rent' ? 'selected' : ''); ?>>Loyer</option>
                            <option value="insurance" <?php echo e($expense->type === 'insurance' ? 'selected' : ''); ?>>Assurance</option>
                            <option value="utilities" <?php echo e($expense->type === 'utilities' ? 'selected' : ''); ?>>Charges</option>
                            <option value="groceries" <?php echo e($expense->type === 'groceries' ? 'selected' : ''); ?>>Courses</option>
                            <option value="other" <?php echo e($expense->type === 'other' ? 'selected' : ''); ?>>Autre</option>
                        </select>
                    </div>

                    <div>
                        <label for="date" class="block text-white mb-2">Date</label>
                        <input type="date" name="date" id="date" required
                            class="w-full bg-darker border border-gray-700 rounded px-4 py-2 text-white focus:outline-none focus:border-dev"
                            value="<?php echo e($expense->date->format('Y-m-d')); ?>">
                    </div>
                </div>

                <div class="space-y-4">
                    <div>
                        <label class="flex items-center space-x-2">
                            <input type="checkbox" name="is_shared" value="1" <?php echo e($expense->is_shared ? 'checked' : ''); ?>

                                class="form-checkbox bg-darker border border-gray-700 text-dev focus:ring-dev">
                            <span class="text-white">Dépense partagée</span>
                        </label>
                    </div>

                    <div>
                        <label class="flex items-center space-x-2">
                            <input type="checkbox" name="locked" value="1" <?php echo e($expense->locked ? 'checked' : ''); ?>

                                class="form-checkbox bg-darker border border-gray-700 text-dev focus:ring-dev">
                            <span class="text-white">Verrouiller cette dépense (ne sera pas supprimée lors de l'archivage mensuel)</span>
                        </label>
                    </div>
                </div>

                <div class="flex justify-end space-x-4">
                    <a href="<?php echo e(route('expenses.index')); ?>"
                        class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition hover-scale">
                        Annuler
                    </a>
                    <button type="submit"
                        class="bg-white hover:bg-gray-100 text-dark font-bold py-2 px-4 rounded transition hover-scale">
                        Enregistrer
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptitlu/Data/code/Budget Mobile/resources/views/expenses/edit.blade.php ENDPATH**/ ?>