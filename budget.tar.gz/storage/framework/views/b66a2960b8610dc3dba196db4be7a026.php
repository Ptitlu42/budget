<?php $__env->startSection('content'); ?>
    <div class="gradient-border">
        <div class="bg-dark p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold flex items-center">
                    <?php if(Auth::user()->email === 'lucas.beyer@gmx.fr'): ?>
                        <i class="fas fa-code text-dev mr-2"></i>
                        <span class="text-dev">Mes Revenus</span>
                    <?php else: ?>
                        <i class="fas fa-lemon text-lemon mr-2"></i>
                        <span class="text-lemon">Mes Revenus</span>
                    <?php endif; ?>
                </h1>
                <a href="<?php echo e(route('incomes.create')); ?>"
                    class="<?php echo e(Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'bg-dev hover:bg-purple-600' : 'bg-lemon hover:bg-yellow-400'); ?> text-dark font-bold py-2 px-4 rounded transition hover-scale">
                    <i class="fas fa-plus mr-2"></i>
                    Ajouter un revenu
                </a>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead>
                        <tr class="<?php echo e(Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-dev' : 'text-lemon'); ?> border-b border-gray-700">
                            <th class="py-2 px-4 text-left">Date</th>
                            <th class="py-2 px-4 text-left">Description</th>
                            <th class="py-2 px-4 text-left">Type</th>
                            <th class="py-2 px-4 text-right">Montant</th>
                            <th class="py-2 px-4 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b border-gray-700 hover:bg-gray-800">
                                <td class="py-2 px-4"><?php echo e($income->date->format('d/m/Y')); ?></td>
                                <td class="py-2 px-4"><?php echo e($income->description); ?></td>
                                <td class="py-2 px-4">
                                    <?php switch($income->type):
                                        case ('salary'): ?>
                                            <span class="flex items-center">
                                                <i class="fas fa-money-bill-wave mr-2 <?php echo e(Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-dev' : 'text-lemon'); ?>"></i>
                                                Salaire
                                            </span>
                                            <?php break; ?>
                                        <?php case ('aid'): ?>
                                            <span class="flex items-center">
                                                <i class="fas fa-hand-holding-heart mr-2 <?php echo e(Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-dev' : 'text-lemon'); ?>"></i>
                                                Aide
                                            </span>
                                            <?php break; ?>
                                        <?php default: ?>
                                            <span class="flex items-center">
                                                <i class="fas fa-plus-circle mr-2 <?php echo e(Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-dev' : 'text-lemon'); ?>"></i>
                                                Autre
                                            </span>
                                    <?php endswitch; ?>
                                </td>
                                <td class="py-2 px-4 text-right font-bold <?php echo e(Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-dev' : 'text-lemon'); ?>">
                                    <?php echo e(number_format($income->amount, 2, ',', ' ')); ?> €
                                </td>
                                <td class="py-2 px-4 text-center">
                                    <div class="flex justify-center items-center space-x-2">
                                        <a href="<?php echo e(route('incomes.edit', $income)); ?>"
                                            class="<?php echo e(Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-dev hover:text-purple-400' : 'text-lemon hover:text-yellow-400'); ?> transition">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('incomes.destroy', $income)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-500 hover:text-red-700 transition"
                                                onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce revenu ?')">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                        <?php if($income->locked): ?>
                                            <span class="<?php echo e(Auth::user()->email === 'lucas.beyer@gmx.fr' ? 'text-dev' : 'text-lemon'); ?>">
                                                <i class="fas fa-lock" title="Ce revenu est verrouillé"></i>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptitlu/Data/code/Budget Mobile/resources/views/incomes/index.blade.php ENDPATH**/ ?>