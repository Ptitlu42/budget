<?php $__env->startSection('content'); ?>
    <div class="bg-dark p-6 rounded-lg shadow-lg max-w-2xl mx-auto">
        <h1 class="text-2xl font-bold text-primary mb-6">Ajouter un revenu</h1>

        <form action="<?php echo e(route('incomes.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label for="description" class="block text-secondary mb-2">Description</label>
                <input type="text" name="description" id="description"
                    class="w-full bg-darker border border-gray-700 rounded p-2 text-white focus:border-secondary focus:outline-none"
                    value="<?php echo e(old('description')); ?>" required>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label for="amount" class="block text-secondary mb-2">Montant (€)</label>
                <input type="number" name="amount" id="amount" step="0.01" min="0"
                    class="w-full bg-darker border border-gray-700 rounded p-2 text-white focus:border-secondary focus:outline-none"
                    value="<?php echo e(old('amount')); ?>" required>
                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-4">
                <label for="type" class="block text-secondary mb-2">Type</label>
                <select name="type" id="type"
                    class="w-full bg-darker border border-gray-700 rounded p-2 text-white focus:border-secondary focus:outline-none">
                    <option value="salary" <?php echo e(old('type') == 'salary' ? 'selected' : ''); ?>>Salaire</option>
                    <option value="aid" <?php echo e(old('type') == 'aid' ? 'selected' : ''); ?>>Aide</option>
                    <option value="other" <?php echo e(old('type') == 'other' ? 'selected' : ''); ?>>Autre</option>
                </select>
                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-6">
                <label for="date" class="block text-secondary mb-2">Date</label>
                <input type="date" name="date" id="date"
                    class="w-full bg-darker border border-gray-700 rounded p-2 text-white focus:border-secondary focus:outline-none"
                    value="<?php echo e(old('date', date('Y-m-d'))); ?>" required>
                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="flex justify-end space-x-4">
                <a href="<?php echo e(route('incomes.index')); ?>"
                    class="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded transition">
                    Annuler
                </a>
                <button type="submit"
                    class="bg-secondary hover:bg-primary text-dark font-bold py-2 px-4 rounded transition">
                    Ajouter
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptitlu/Data/code/Budget Mobile/resources/views/incomes/create.blade.php ENDPATH**/ ?>