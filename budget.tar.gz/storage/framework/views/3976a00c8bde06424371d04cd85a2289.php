<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/history/styles.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div class="gradient-border hover-scale">
            <div class="bg-dark p-6">
                <h3 class="text-white mb-2 flex items-center">
                    <i class="fas fa-euro-sign mr-2"></i>
                    Revenus Totaux
                </h3>
                <p class="text-2xl font-bold text-white">
                    <?php echo e(number_format(App\Models\Income::sum('amount'), 2, ',', ' ')); ?> €
                </p>
            </div>
        </div>
        <div class="gradient-border hover-scale">
            <div class="bg-dark p-6">
                <h3 class="text-white mb-2 flex items-center">
                    <i class="fas fa-wallet mr-2"></i>
                    Dépenses Totales
                </h3>
                <p class="text-2xl font-bold text-white">
                    <?php echo e(number_format(App\Models\Expense::sum('amount'), 2, ',', ' ')); ?> €
                </p>
            </div>
        </div>
        <div class="gradient-border hover-scale">
            <div class="bg-dark p-6">
                <h3 class="text-white mb-2 flex items-center">
                    <i class="fas fa-hand-holding-euro mr-2"></i>
                    Dépenses Communes
                </h3>
                <p class="text-2xl font-bold text-white">
                    <?php echo e(number_format(App\Models\Expense::where('is_shared', true)->sum('amount'), 2, ',', ' ')); ?> €
                </p>
            </div>
        </div>
        <div class="gradient-border hover-scale">
            <div class="bg-dark p-6">
                <h3 class="text-white mb-2 flex items-center">
                    <i class="fas fa-user-tag mr-2"></i>
                    Dépenses Individuelles
                </h3>
                <p class="text-2xl font-bold text-white">
                    <?php echo e(number_format(App\Models\Expense::where('is_shared', false)->sum('amount'), 2, ',', ' ')); ?> €
                </p>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div class="gradient-border hover-scale">
            <div class="bg-dark p-6">
                <h2 class="text-xl font-bold text-white mb-4 flex items-center">
                    <i class="fas fa-chart-bar mr-2"></i>
                    Revenus par personne
                </h2>
                <?php
                    $users = DB::table('incomes')
                        ->join('users', 'incomes.user_id', '=', 'users.id')
                        ->select('users.name', 'users.email', DB::raw('SUM(amount) as total_income'))
                        ->groupBy('users.id', 'users.name', 'users.email')
                        ->get();
                ?>
                <div class="space-y-4">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="glass-effect p-4 rounded hover-scale">
                            <div class="flex justify-between items-center mb-2">
                                <span class="flex items-center">
                                    <?php if($user->email === 'lucas.beyer@gmx.fr'): ?>
                                        <i class="fas fa-code text-dev mr-2"></i>
                                        <span class="text-dev"><?php echo e($user->name); ?></span>
                                    <?php else: ?>
                                        <i class="fas fa-lemon text-lemon mr-2"></i>
                                        <span class="text-lemon"><?php echo e($user->name); ?></span>
                                    <?php endif; ?>
                                </span>
                                <span class="font-bold <?php echo e($user->email === 'lucas.beyer@gmx.fr' ? 'text-dev' : 'text-lemon'); ?>">
                                    <?php echo e(number_format($user->total_income, 2, ',', ' ')); ?> €
                                </span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="gradient-border hover-scale">
            <div class="bg-dark p-6">
                <h2 class="text-xl font-bold text-white mb-4 flex items-center">
                    <i class="fas fa-chart-pie mr-2"></i>
                    Répartition des revenus
                </h2>
                <canvas id="revenusChart" class="w-full" data-users="<?php echo e(json_encode($users)); ?>"></canvas>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="gradient-border hover-scale">
            <div class="bg-dark p-6">
                <h2 class="text-xl font-bold text-white mb-4 flex items-center">
                    <i class="fas fa-calculator mr-2"></i>
                    Part des dépenses communes
                </h2>
                <?php
                    $totalIncomes = App\Models\Income::sum('amount');
                    $shares = DB::table('incomes')
                        ->join('users', 'incomes.user_id', '=', 'users.id')
                        ->select('users.name', 'users.email', DB::raw('SUM(amount) as total_income'))
                        ->groupBy('users.id', 'users.name', 'users.email')
                        ->get()
                        ->map(function ($user) use ($totalIncomes) {
                            $user->share_percentage = ($totalIncomes > 0) ? ($user->total_income / $totalIncomes) * 100 : 0;
                            return $user;
                        });
                    $totalSharedExpenses = App\Models\Expense::where('is_shared', true)->sum('amount');
                ?>
                <div class="space-y-4">
                    <?php $__currentLoopData = $shares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $share): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="glass-effect p-4 rounded hover-scale">
                            <div class="flex justify-between items-center mb-2">
                                <span class="flex items-center">
                                    <?php if($share->email === 'lucas.beyer@gmx.fr'): ?>
                                        <i class="fas fa-code text-dev mr-2"></i>
                                        <span class="text-dev"><?php echo e($share->name); ?></span>
                                    <?php else: ?>
                                        <i class="fas fa-lemon text-lemon mr-2"></i>
                                        <span class="text-lemon"><?php echo e($share->name); ?></span>
                                    <?php endif; ?>
                                </span>
                                <span class="font-bold <?php echo e($share->email === 'lucas.beyer@gmx.fr' ? 'text-dev' : 'text-lemon'); ?>">
                                    <?php echo e(number_format(($totalSharedExpenses * $share->share_percentage / 100), 2, ',', ' ')); ?> €
                                </span>
                            </div>
                            <div class="w-full bg-gray-700 rounded-full h-2">
                                <div class="<?php echo e($share->email === 'lucas.beyer@gmx.fr' ? 'bg-dev' : 'bg-lemon'); ?> progress-bar" data-width="<?php echo e($share->share_percentage); ?>"></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="gradient-border hover-scale">
            <div class="bg-dark p-6">
                <h2 class="text-xl font-bold text-white mb-4 flex items-center">
                    <i class="fas fa-tags mr-2"></i>
                    Dépenses par catégorie
                </h2>
                <canvas id="depensesChart" class="w-full" data-expenses="<?php echo e(json_encode([
                    'rent' => App\Models\Expense::where('type', 'rent')->sum('amount'),
                    'insurance' => App\Models\Expense::where('type', 'insurance')->sum('amount'),
                    'utilities' => App\Models\Expense::where('type', 'utilities')->sum('amount'),
                    'groceries' => App\Models\Expense::where('type', 'groceries')->sum('amount'),
                    'other' => App\Models\Expense::where('type', 'other')->sum('amount')
                ])); ?>"></canvas>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ptitlu/Data/code/Budget Mobile/resources/views/dashboard.blade.php ENDPATH**/ ?>